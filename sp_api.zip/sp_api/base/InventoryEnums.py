from enum import Enum


class InventoryGranularity(Enum):
    MARKETPLACE = "Marketplace"
